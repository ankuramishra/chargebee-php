<?php

namespace ChargeBee\ChargeBee\Models;

use ChargeBee\ChargeBee\Model;

class CreditNoteEstimateTax extends Model
{
  protected $allowed = [
    'name',
    'amount',
    'description',
  ];

}

?>