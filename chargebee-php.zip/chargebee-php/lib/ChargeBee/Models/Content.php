<?php
namespace ChargeBee\ChargeBee\Models;

use ChargeBee\ChargeBee\Result;

class Content extends Result
{
	
}
?>