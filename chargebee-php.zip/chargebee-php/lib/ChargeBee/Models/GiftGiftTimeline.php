<?php

namespace ChargeBee\ChargeBee\Models;

use ChargeBee\ChargeBee\Model;

class GiftGiftTimeline extends Model
{
  protected $allowed = [
    'status',
    'occurredAt',
  ];

}

?>