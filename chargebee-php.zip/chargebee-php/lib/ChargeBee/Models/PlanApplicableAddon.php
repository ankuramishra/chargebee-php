<?php

namespace ChargeBee\ChargeBee\Models;

use ChargeBee\ChargeBee\Model;

class PlanApplicableAddon extends Model
{
  protected $allowed = [
    'id',
  ];

}

?>