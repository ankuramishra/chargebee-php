<?php

namespace ChargeBee\ChargeBee\Models;

use ChargeBee\ChargeBee\Model;

class ItemApplicableItem extends Model
{
  protected $allowed = [
    'id',
  ];

}

?>