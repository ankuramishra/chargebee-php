<?php

namespace ChargeBee\ChargeBee;

final class Version
{
	  const VERSION = '3.1.0';
}

?>
